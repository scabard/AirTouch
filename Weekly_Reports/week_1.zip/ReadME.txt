
**** Authors : Satyam Shukla(B17058), Sambhav Dusad(B17056), Saransh Sharma(B17057) ***

AirTouch is an application software which will recognize gestures and based on that will do some actions in media player like VLC
To use it, do the following :-
-> Open terminal and type 'git clone https://github.com/scabard/AirTouch.git'
-> Open  AirTouch folder in terminal
-> Write the command 'python main.py'

To see the repository go to https://github.com/scabard/AirTouch
